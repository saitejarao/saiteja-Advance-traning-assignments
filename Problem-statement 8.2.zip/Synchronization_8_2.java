package problem_statements;

class Storage1{
	int i;
	boolean printed = true;

	public void setValue(int i) {
		this.i = i;
	}

	public int getValue() {
		return this.i;
	}

	public boolean isPrinted() {
		return printed;
	}

	public void setPrinted(boolean p) {
		printed = p;
	}
}

class Counter1 implements Runnable {

	Storage1 s;
	public Counter1(Storage1 store) {
		s = store;
	}

	@Override
	public void run() {
		synchronized (s) {
			for (int i = 0; i < 10; i++) {
				while (!s.isPrinted()) { 
					try {
						s.wait();
					} catch (Exception e) {
					}
				}
				s.setValue(i);
				s.setPrinted(false);
				s.notify();
			}
		}
	}

}

class Printer1 implements Runnable {
	Storage1 s;

	public Printer1(Storage1 s) {
		this.s = s;
	}

	@Override
	public void run() {
		synchronized (s) {
			for (int i = 0; i < 10; i++) {
				while (s.isPrinted()) { 
					try {
						s.wait();
					} catch (Exception e) {
					}
				}
				System.out.println(Thread.currentThread().getName() + " " + s.getValue());
				s.setPrinted(true);
				s.notify();
			}
		}
	}

}

public class Synchronization_8_2 {
	public static void main(String[] args) {
		Storage1 s = new Storage1();
		Counter1 c = new Counter1(s);
		Printer1 p = new Printer1(s);
		new Thread(c, "Counter").start();
		new Thread(p, "Printer").start(); 
	}
}
