package problem_statements;

public class array_2_3 {
	
	public static void main(String[] args) {
		int A[] = {3, 2, 4, 5, 6, 4, 5, 7, 3, 2, 3, 4, 7, 1, 2, 0, 0, 0};
		int sum=0,i;

		for(i=0;i<=14;i++) {
			sum=sum+A[i];
		}
		A[15]=sum;
		System.out.println("A[15]:"+A[15]);
		
		int Average=sum/A.length;
		System.out.println("A[16]:"+Average);
		
		int smallest = A[0];
		for (int j = 0; j < A.length; j++) {
		    if (A[j] < smallest) {
		        smallest = A[j];
		    }
		}
		System.out.println("A[17]:"+smallest);
	}

}
