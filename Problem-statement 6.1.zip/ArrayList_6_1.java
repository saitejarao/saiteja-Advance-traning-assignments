package problem_statements;

import java.util.ArrayList;
import java.util.Scanner;

public class ArrayList_6_1 {

	public static void main(String[] args) {
		
		ArrayList<String> student=new ArrayList<>();
        student.add("jai");
        student.add("ram");
        student.add("sri");
        student.add("krishna");
        student.add("vijay");
        System.out.println(student);
        
        System.out.println("Enter the searching name:");
        Scanner sc=new Scanner(System.in);
        String str=sc.nextLine();
        if (student.contains(str)) {
            System.out.println("Name exists");
            } else {
            System.out.println("Name not found");
            }
	}
}
