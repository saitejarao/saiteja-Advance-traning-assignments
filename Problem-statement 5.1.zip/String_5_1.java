package problem_statements;

public class String_5_1 {
	
	public static void main(String[] args) {
		String str="JAVA is Simple";
		
		String u=str.toUpperCase();
		System.out.println(u);
		String y=str.toLowerCase();
		System.out.println(y);
		
		String[] letter=str.split("\\s");
		for(String l:letter){  
			System.out.print(l.charAt(0)); 
			System.out.print(" ");
		}
		System.out.println(" ");
		
		String[] letter2=str.split("\\s");  
		for(String l:letter2){  
			System.out.println(l); 
		}
		
		StringBuilder word= new StringBuilder("JAVA is Simple");
		StringBuilder reverseStr = word.reverse();
		System.out.println("Reverse String = " + reverseStr.toString());
		
		int g=str.length();
		System.out.println(g);
	}

}
