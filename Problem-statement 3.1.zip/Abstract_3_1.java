package problem_statements;

abstract class Instrument{
  abstract void play();
}
class piano extends Instrument{

	@Override
	void play() {
		// TODO Auto-generated method stub
		System.out.println("Piano is playing tan tan tan tan");
	}
}
class flute extends Instrument{

	@Override
	void play() {
		// TODO Auto-generated method stub
		System.out.println("Flute is playing toot toot toot toot");
	}
}
class guitar extends Instrument{

	@Override
	void play() {
		// TODO Auto-generated method stub
		System.out.println("Guitar is playing tin tin tin");
	}
}

public class Abstract_3_1 {
public static void main(String args[]) {
	Instrument A[] = new Instrument[10];
	for (int i=0; i<10; i++)
	{
	switch (i%3)
	  {
	    case 0: { A[i] = new piano(); break; }
	    case 1: { A[i] = new flute(); break; }
	    case 2: { A[i] = new guitar(); break; }
	  }
	}
	for (int i=0; i<10; i++)
	{
	  System.out.println("------------------------------------");
	  System.out.println(" object =>" + (i+1));
	  A[i].play();
	  if (A[i] instanceof piano) { System.out.println("Piano"); }
	  if (A[i] instanceof flute) { System.out.println("Flute"); }
	  if (A[i] instanceof guitar) { System.out.println("Guitar"); }
	}
}
}
