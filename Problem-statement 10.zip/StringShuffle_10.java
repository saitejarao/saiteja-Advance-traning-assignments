package problem_statements;

import java.util.Arrays;

public class StringShuffle_10 {
    static boolean Length(String first,String second,String third) {
    	if(first.length()+second.length() == third.length()) {
    		return true;}
    		else {
    		return false;}
    	}
    static String sortString(String s) {
    	char[] ch=s.toCharArray();
    	Arrays.sort(ch);
    	s=String.valueOf(ch);
    	return s;
    }
    static boolean shuffle(String first,String second,String third) {
    	first=sortString(first);
    	second=sortString(second);
    	third=sortString(third);
    	int a=0,b=0,c=0;
    	while(c!=third.length()) {
    		if(a<first.length()&&first.charAt(a) == third.charAt(c))
    			a++;
    		else if(b<second.length()&&second.charAt(b) == third.charAt(c))
    			b++; 
    		else {
    			return false;
    		}
    		c++;
    	}
    	if(a<first.length() || b<second.length()) {
    		return false;
    	}
		return true;	
    }
	public static void main(String[] args) {
		String first="abc";
		String second="def";
		String[] results={"dabecf","fcebda","daebcf","abcdef","caegbf"};
		
		for(String third:results) {
			if(Length(first,second,third)==true && shuffle(first,second,third)==true) {
			System.out.println(third+"is a valid shuffle of"+first+"and"+second);}
			else {
	        System.out.println(third+"is not a valid shuffle of"+first+"and"+second);
	        }
			}
		}
		

	

}
