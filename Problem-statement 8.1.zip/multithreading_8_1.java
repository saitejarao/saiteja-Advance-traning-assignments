package problem_statements;

class Storage {
	  private int x;
	  public Storage(int y) { x=y; }
	  public int test() { return(x); }
	  public Storage(Storage s) { this.x = s.test(); }
}
class Printer implements Runnable
{
	  private Storage storage;
	  Printer(Storage s) { storage = new Storage(s); }
	  public void run()
	  {
	    System.out.println(storage.test());
	  }
}
class Counter implements Runnable
{
	private int a;
	public Counter(int b) { a=b; }
	public int test() { return(a); }
	public void run()
	{
	  for (int i=1;i<=a;i++)
	   {
	     Storage storage = new Storage(i);
	     Printer printer = new Printer(storage);
	     Thread.yield();
	     printer.run();
	   }
	}
}
public class multithreading_8_1{
	public static void main(String[] args) {
		Storage s = new Storage(35);
		Counter c = new Counter(14);
		Printer p = new Printer(s);
		new Thread(c, "Counter").start();
		new Thread(p, "Printer").start(); 
	}
}
