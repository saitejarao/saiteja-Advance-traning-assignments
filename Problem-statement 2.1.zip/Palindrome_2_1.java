package problem_statements;

import java.util.Scanner;

public class Palindrome_2_1 {
	public static void main(String args[])
	   {
	      String g,reverse="" ;
	      Scanner scan = new Scanner(System.in);
	 
	      System.out.println("Enter a string:");
	      g = scan.nextLine();
	 
	      int length = g.length();
	 
	      for ( int i = length - 1; i >= 0; i-- ) {
	         reverse = reverse + g.charAt(i);}
	 
	      if (g.equals(reverse)) 
	         System.out.println(g+" is a palindrome");
	      else
	         System.out.println(g+" is not a palindrome");
	      
	   }
}
