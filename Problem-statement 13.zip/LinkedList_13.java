package problem_statements;

public class LinkedList_13 {
	 static test head; 
	 
	   class test {
	        int g;
	        test next;
	        test(int d)
	        {
	            g = d;
	            next = null;
	        }
	    }
	
	    static void FindNthNode(int n)
	    {
	    	test primary = head;
	    	test reference = head;
	 
	        int count = 0;
	        if (head != null)
	        {
	            while (count < n)
	            {
	                if (reference == null)
	                {
	                    System.out.println(n
	                     + " is greater than the no "
	                       + " of nodes  Value in the list -1");
	                    return;
	                }
	                reference = reference.next;
	                count++;
	            }
	 
	            if(reference == null)
	            {
	              
	              if(head != null)
	                System.out.println("Node no. " + n +
	                                   " from last is " +
	                                      head.g);
	            }
	            else
	            {
	                   
	              while (reference != null)
	              {
	            	  primary = primary.next;
	                  reference = reference.next;
	              }
	              System.out.println("Node no.  from last second is  : " +primary.g);                       
	            }
	        }
	    }
	 
	   
	    public void push(int new_data)
	    {
	        test s = new test(new_data);
	        s.next = head;
	        head = s;
	    }
	 
	    public static void main(String[] args)
	    {
	        LinkedList_13 l = new LinkedList_13();
	        l.push(1);
	        l.push(2);
	        l.push(3);
	        l.push(4);
	        l.push(5);
	        l.push(6);
	        l.push(7);
	        l.push(8);
	        l.push(9);
	        l.push(10);
	 
	        FindNthNode(9);
	        FindNthNode(12);
	    }
}
