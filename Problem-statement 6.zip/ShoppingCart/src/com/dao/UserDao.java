package com.dao;

import java.sql.*;

import java.sql.ResultSet;

import com.models.Book;
import com.models.Users;

public class UserDao {
	private Connection con;

	public UserDao() {
		super();
		
	}
	public UserDao(Connection con) {
		this.con = con;
	}
//	method to insert in database
	public boolean saveUser(Users users) {
		boolean f=false;

		try {
			String query="insert into users(first_name,address,email,user_name,password)values (?,?,?,?,?)";
			PreparedStatement pstmt	=this.con.prepareStatement(query);
			pstmt.setString(1,users.getFirst_name());
			pstmt.setString(2,users.getAddress());
			pstmt.setString(3,users.getEmail());
			pstmt.setString(4,users.getUser_name());
			pstmt.setString(5,users.getPassword());
			
			pstmt.executeUpdate();
			f=true;
		
		} catch (Exception e) {
			e.printStackTrace();
		}
		return f;

	}
	public Users getUserByUnameAndPassword(String uname, String password) {
		Users user=null;
		try {
			String query="select * from users where user_name=? and password=?";
			
			PreparedStatement psmt=con.prepareStatement(query);
			psmt.setString(1, uname);
			psmt.setString(2, password);
			
			ResultSet set=psmt.executeQuery();
			
			if(set.next()) {
				user=new Users(query, query, query, query, query, null);
				//data from db
				user.setFirst_name(set.getString("fname"));
				//set to user object
				user.setAddress(set.getString("address"));
				user.setEmail(set.getString("email"));
				user.setUser_name(uname);
				user.setPassword(set.getString("password"));
				user.setRegdate(set.getTimestamp("rdate"));
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return user;
	}
	public Users resetPassword(String email, String user_name) {
		Users users=null;
		try {
			String query="select * from users where email=? and user_name=?";
			
			PreparedStatement psmt=con.prepareStatement(query);
			psmt.setString(1, email);
			psmt.setString(2, user_name);
			
			ResultSet set=psmt.executeQuery();
			
			if(set.next()) {
				users=new Users(query, query, query, query, query, null);
				//data from db
				users.setFirst_name(set.getString("fname"));
				//set to user object
				users.setAddress(set.getString("address"));
				users.setEmail(set.getString("email"));
				users.setUser_name(user_name);
				users.setPassword(set.getString("password"));
				users.setRegdate(set.getTimestamp("rdate"));
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return users;
	}
    public int setPassword(String pass) throws SQLException {
		
		String query="update users set password=? where user_name=?";
		Users user=new Users(query, query, query, query, query);
		PreparedStatement psmt=con.prepareStatement(query);
		psmt.setString(1, pass);
		psmt.setString(2,(user.getUser_name()));
		return psmt.executeUpdate();
	}
    public Book getBookDetails(String bookId) throws Exception {
    	Book b=null;
		try {
			String query="select * from book where book_id=?";
			
			PreparedStatement psmt=con.prepareStatement(query);
			psmt.setString(1, bookId);
			
			ResultSet set=psmt.executeQuery();
			
			if(set.next()) {
				b=new Book();
				b.setBook_id(set.getString("Book_id"));
				b.setBoook_name(set.getString("Book_name"));
				b.setAuthor(set.getString("Author"));
				b.setPrice(set.getString("Price"));
				
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return b;
	 }
}
