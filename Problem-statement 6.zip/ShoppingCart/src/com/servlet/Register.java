package com.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dao.UserDao;
import com.database.connection;
import com.models.Users;

@WebServlet("/Register")
public class Register extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public Register() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out= response.getWriter();
		response.setContentType("text/html");
	
			String first_name=request.getParameter("First_name");
			String address=request.getParameter("address");
			String email=request.getParameter("email");
			String user_name=request.getParameter("User_name");
			String password=request.getParameter("password");
//			user object save all data to user object
			
			Users users=new Users(first_name,address,email,user_name,password);
//			user dao object
			UserDao dao=new UserDao(connection.getConnection());
			if(dao.saveUser(users)) {
				out.println("Register");
				response.sendRedirect("Login.jsp");
			}
			else {
				out.println("Registratin failed!!");
			}
	}

}
