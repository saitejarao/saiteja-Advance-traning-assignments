package com.models;

public class BookOrderDetails {
	int Order_id;
	int Book_id;
	String Cust_name;
	long Phone_no;
	String Address;
	String Order_date;
	int Quantity;
	public int getOrder_id() {
		return Order_id;
	}
	public void setOrder_id(int order_id) {
		Order_id = order_id;
	}
	public int getBook_id() {
		return Book_id;
	}
	public void setBook_id(int book_id) {
		Book_id = book_id;
	}
	public String getCust_name() {
		return Cust_name;
	}
	public void setCust_name(String cust_name) {
		Cust_name = cust_name;
	}
	public long getPhone_no() {
		return Phone_no;
	}
	public void setPhone_no(long phone_no) {
		Phone_no = phone_no;
	}
	public String getAddress() {
		return Address;
	}
	public void setAddress(String address) {
		Address = address;
	}
	public String getOrder_date() {
		return Order_date;
	}
	public void setOrder_date(String order_date) {
		Order_date = order_date;
	}
	public int getQuantity() {
		return Quantity;
	}
	public void setQuantity(int quantity) {
		Quantity = quantity;
	}
	public BookOrderDetails(int order_id, int book_id, String cust_name, long phone_no, String address,
			String order_date, int quantity) {
		super();
		Order_id = order_id;
		Book_id = book_id;
		Cust_name = cust_name;
		Phone_no = phone_no;
		Address = address;
		Order_date = order_date;
		Quantity = quantity;
	}
	public BookOrderDetails() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "BookOrderDetails [Order_id=" + Order_id + ", Book_id=" + Book_id + ", Cust_name=" + Cust_name
				+ ", Phone_no=" + Phone_no + ", Address=" + Address + ", Order_date=" + Order_date + ", Quantity="
				+ Quantity + "]";
	}
	
}
