package com.models;

public class Book {
String Book_id;
String Boook_name;
String Author;
String price;
public String getBook_id() {
	return Book_id;
}
public void setBook_id(String book_id) {
	Book_id = book_id;
}
public String getBoook_name() {
	return Boook_name;
}
public void setBoook_name(String boook_name) {
	Boook_name = boook_name;
}
public String getAuthor() {
	return Author;
}
public void setAuthor(String author) {
	Author = author;
}
public String getPrice() {
	return price;
}
public void setPrice(String price) {
	this.price = price;
}
@Override
public String toString() {
	return "Book [Book_id=" + Book_id + ", Boook_name=" + Boook_name + ", Author=" + Author + ", price=" + price + "]";
}
public Book(String book_id, String boook_name, String author, String price) {
	super();
	Book_id = book_id;
	Boook_name = boook_name;
	Author = author;
	this.price = price;
}
public Book() {
	super();
	// TODO Auto-generated constructor stub
}

}
