package com.models;

import java.sql.Timestamp;

public class Users {
String First_name;
String address;
String email;
String User_name;
String password;
Timestamp Regdate;

public Users(String first_name, String address, String email, String user_name, String password,Timestamp Regdate) {
	
	this.First_name = first_name;
	this.address = address;
	this.email = email;
	this.User_name = user_name;
	this.password = password;
	Regdate = Regdate;
}
public Users(String first_name, String address, String email, String user_name, String password) {
	
	this.First_name = first_name;
	this.address = address;
	this.email = email;
	this.User_name = user_name;
	this.password = password;
	
}
public Timestamp getRegdate() {
	return Regdate;
}
public void setRegdate(Timestamp timestamp) {
	Regdate = timestamp;
}
public String getFirst_name() {
	return First_name;
}
public void setFirst_name(String first_name) {
	First_name = first_name;
}
public String getAddress() {
	return address;
}
public void setAddress(String address) {
	this.address = address;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public String getUser_name() {
	return User_name;
}
public void setUser_name(String user_name) {
	User_name = user_name;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}

@Override
public String toString() {
	return "Users [First_name=" + First_name + ", address=" + address + ", email=" + email + ", User_name=" + User_name
			+ ", password=" + password + ", Regdate=" + Regdate + "]";
}

}
