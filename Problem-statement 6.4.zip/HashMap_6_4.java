package problem_statements;

import java.util.HashMap;
import java.util.Scanner;

public class HashMap_6_4 {

	public static void main(String[] args) {
		HashMap<String,String> hm=new HashMap<String,String>();
		hm.put("sai", "7702463506");
		hm.put("jai","7702463507");
		
		 System.out.println("1.Add phone number\n2.Search the phone number\n3.quit");
		 while(true){
	   
		 System.out.println("\nEnter your choice:\t");
		 
	     Scanner sc1 = new Scanner(System.in);
	     int  options =  sc1.nextInt(); 
	   
	   switch (options)
	   { 
	    case 1:
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the Phone number:");
		hm.put(sc.next(),sc.next());
		break;
        
        case 2:
        System.out.println("Enter the Name for searching a phone number:");
		String sid=sc1.next();
		if(hm.containsKey(sid))
		{
			System.out.println(hm.get(sid));
		}
		else {
			System.out.println("do not exist");
		}
		break;
		 
        case 3:
        closeApp();
        break;
		}
		}
	}
	private static void closeApp() {
        System.out.println("Closing your application... \nThank you!");
            }
}