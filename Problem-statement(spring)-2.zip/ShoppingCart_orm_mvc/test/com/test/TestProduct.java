package com.test;

import junit.framework.TestCase;

public class TestProduct extends TestCase {

}
