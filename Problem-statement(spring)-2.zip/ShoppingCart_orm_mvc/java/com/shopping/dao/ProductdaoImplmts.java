package com.shopping.dao;


import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Component;

import com.shopping.models.ShoppingProduct;

@Component
public class ProductdaoImplmts implements ProductDao {
    
	@Autowired
	private HibernateTemplate hibernatetempl;
	
	
	public List<ShoppingProduct> allProducts() {
		List<ShoppingProduct> s=this.hibernatetempl.loadAll(ShoppingProduct.class);
		return s;
	}

	@Transactional
	public void addProduct(ShoppingProduct sp) {
		this.hibernatetempl.saveOrUpdate(sp);
		
	}


	public ShoppingProduct getProductById(int id) {
		return this.hibernatetempl.get(ShoppingProduct.class,id);
	}

	@Transactional
	public void DeleteProductById(int id) {
		ShoppingProduct s=this.hibernatetempl.load(ShoppingProduct.class,id);
		this.hibernatetempl.delete(s);
	}

	@Transactional
	public ShoppingProduct UpdateProductById(int id) {
		ShoppingProduct s=this.hibernatetempl.load(ShoppingProduct.class,id);
		 this.hibernatetempl.update(s);
		return s;	
	}

	public List<ShoppingProduct> allProdsByCategory(String category) throws DataAccessException  {
		return (List<ShoppingProduct>) this.hibernatetempl.find("from ShoppingProduct p where p.category=?", category);
	}


	public List<ShoppingProduct> allProdsByBrandModel(String brand, String model) throws DataAccessException {
		return (List<ShoppingProduct>) this.hibernatetempl.find("from ShoppingProduct p where p.brand=? and p.model=?",brand,model );
	}


	public List<ShoppingProduct> allProdsByBorM(String brand, String model) throws DataAccessException  {
		return (List<ShoppingProduct>) this.hibernatetempl.find("from ShoppingProduct p where p.brand=? or p.model=?",brand,model);
	}


	public List<ShoppingProduct> allProdsBYBorMorC(String brand, String model, String category) throws DataAccessException  {
		return (List<ShoppingProduct>) this.hibernatetempl.find("from ShoppingProduct p where p.brand=? or p.model=? or p.category=?",brand,model,category);
	}
}
