package com.shopping.service;

import java.util.List;

import com.shopping.models.ShoppingProduct;

public interface ProductService {
	public void addProduct(ShoppingProduct sp);
	public ShoppingProduct getProductById(int id);
	public void DeleteProductById(int id);
	public ShoppingProduct UpdateProductById(int id);
	public List<ShoppingProduct> allProducts();
	public List<ShoppingProduct> allProdsByCategory(String category);
	public List<ShoppingProduct> allProdsByBrandModel(String brand,String model);
	public List<ShoppingProduct> allProdsByBorM(String brand,String model);
	public List<ShoppingProduct> allProdsBYBorMorC(String brand,String model,String category);
}
