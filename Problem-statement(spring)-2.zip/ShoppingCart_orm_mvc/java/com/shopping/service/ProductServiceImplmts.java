package com.shopping.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.shopping.dao.ProductDao;
import com.shopping.dao.ProductdaoImplmts;
import com.shopping.models.ShoppingProduct;

@Service
public class ProductServiceImplmts implements ProductService {
    
	@Autowired
	private ProductDao dao;
	
	public void addProduct(ShoppingProduct sp) {
		dao.addProduct(sp);
	}

	public ShoppingProduct getProductById(int id) {
		return dao.getProductById(id);
	}

	public void DeleteProductById(int id) {
		dao.DeleteProductById(id);
		
	}

	public ShoppingProduct UpdateProductById(int id) {
		dao.UpdateProductById(id);
		return null;
		
	}

	public List<ShoppingProduct> allProducts() {
		
		return dao.allProducts();
	}

	public List<ShoppingProduct> allProdsByCategory(String category) {
		
		return dao.allProdsByCategory(category);
	}

	public List<ShoppingProduct> allProdsByBrandModel(String brand, String model) {
		return dao.allProdsByBrandModel(brand, model);
	}

	public List<ShoppingProduct> allProdsByBorM(String brand, String model) {
		
		return dao.allProdsByBorM(brand, model);
	}

	public List<ShoppingProduct> allProdsBYBorMorC(String brand, String model, String category) {
		
		return dao.allProdsBYBorMorC(brand, model, category);
	}
}