package problem_statements;

import java.util.Scanner;

public class sequence_2_2 {
	
	public static void main(String[] args) {
		int a,b,g,t,f;
		
		System.out.println("Enter the first number");
		Scanner sc1=new Scanner(System.in);
		a=sc1.nextInt();
		System.out.println("Enter the second number");
		Scanner sc=new Scanner(System.in);
		b=sc.nextInt();
		System.out.println("Output:");
		System.out.println(a);
		System.out.println(b);
		for(int i = 1;i <= 13;i++) {
		g=a+b;
		t=b;
		f=g;
		a=t;
		b=f;
		System.out.println(g);	
		}
	}

}

