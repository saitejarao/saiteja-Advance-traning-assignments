package problem_statements;

import java.util.Hashtable;
import java.util.Scanner;

public class product_6_2 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Hashtable<String,String> hash=new Hashtable<String,String>();
		System.out.println("Enter the Product Id and Name:");
		for(int i=0;i<3;i++)
		{
			hash.put(sc.next(),sc.next());
		}
		System.out.println("List of Products:");
		System.out.println(hash);
		System.out.println("Enter the product id to be removed:");
		String id = sc.next();
		hash.remove(id);
		System.out.println("Item removed");
		System.out.println("List of Products:");
		System.out.println(hash.toString());
		System.out.println("Enter the product id to be searched:");
		String sid=sc.next();
		if(hash.containsKey(sid))
		{
			System.out.println(hash.get(sid));
		}
		else {
			System.out.println("do not exist");
		}

	}

}
