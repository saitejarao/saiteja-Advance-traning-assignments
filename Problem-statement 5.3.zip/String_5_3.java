package problem_statements;

import java.util.Scanner;

public class String_5_3 {
	
    static void printRotated(String str)
    {
        int len = str.length();
      
        StringBuffer sb;
         
        for (int i = 0; i < len; i++)
        {
            sb = new StringBuffer();
             
            int j = i; 
            int k = 0; 
      
            for (int k2 = j; k2 < len; k2++) {
                sb.insert(k, str.charAt(j));
                k++;
                j++;
            }
      
           j = 0;
            while (j < i)
            {
                sb.insert(k, str.charAt(j));
                j++;
                k++;
            }
      
            System.out.println(sb);
        }
    }
	public static void main(String[] args) {
		String  str;
		System.out.println("Enter the string");
		Scanner scan=new Scanner(System.in);
		str=scan.nextLine();
        printRotated(str);
	}

}