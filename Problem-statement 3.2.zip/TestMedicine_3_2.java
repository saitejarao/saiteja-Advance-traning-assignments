package problem_statements;

interface MedicineInfo{
	abstract void displayLabel();
}

class Tablet implements MedicineInfo{

	@Override
	public void displayLabel() {
		System.out.println("Store in a cool dry place");		
	}
	
}
class syrup implements MedicineInfo{

	@Override
	public void displayLabel() {
		System.out.println("Shake well before use");		
	}
	
}
class Ointment implements MedicineInfo{

	@Override
	public void displayLabel() {
		System.out.println("For external use only");		
	}
	
}

public class TestMedicine_3_2 {

	public static void main(String[] args) {
		MedicineInfo m[] = new MedicineInfo[10];
		for (int i=0; i<10; i++)
		{
		switch (i%3)
		  {
		    case 0: { m[i] = new Tablet(); break; }
		    case 1: { m[i] = new syrup(); break; }
		    case 2: { m[i] = new Ointment(); break; }
		  }
		}
		for (int i=0; i<10; i++)
		{
		  System.out.println("------------------------------------");
		  System.out.println(" object =>" + (i+1));
		  m[i].displayLabel();
		  if (m[i] instanceof Tablet) { System.out.println("Tablet"); }
		  if (m[i] instanceof syrup) { System.out.println("Syrup"); }
		  if (m[i] instanceof Ointment) { System.out.println("Ointment"); }
		}

	}

}
