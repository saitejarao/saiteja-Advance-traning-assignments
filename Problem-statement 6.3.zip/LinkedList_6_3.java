package problem_statements;

import java.util.LinkedList;

class Employee{
	int employeeNo;
	String employeeName,address;
	public Employee(int employeeNo, String employeeName, String address) {
		super();
		this.employeeNo = employeeNo;
		this.employeeName = employeeName;
		this.address = address;
	}
	
}
public class LinkedList_6_3 {
	static LinkedList<Employee> emp=new LinkedList<Employee>();	
	public static void addinput() {
		System.out.println("EmpNO  EmpName EmpAddress");
		Employee e1=new Employee(40980,"Jai   ","Hyderabad");
		Employee e2=new Employee(40981,"Sanket","Delhi");
		Employee e3=new Employee(40982,"Ramesh","Vijayawada");
		Employee e4=new Employee(40983,"Vikram","Chennai");
		Employee e5=new Employee(40984,"Dharma","Mumbai");
		emp.add(e1);
		emp.add(e2);
		emp.add(e3);
		emp.add(e4);
		emp.add(e5);
	}
	public static void display() {
		for(Employee e:emp ) {
			
			System.out.println(e.employeeNo+"  "+e.employeeName+"  "+e.address);
		}
	}
public static void main(String args[]) {
	
	addinput();
	display();
}

}
