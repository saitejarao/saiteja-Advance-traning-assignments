package problem_statements;

import java.util.Arrays;

public class MergingArrays_14 {
   public static void Merging(int x[],int y[],int r[],int l,int m) {
	   Arrays.sort(x);
	   Arrays.sort(y);
	   int i=0,j=0,k=0;
	   while(i<l && j<m) {
		  if(x[i] <= y[j]) {
			  r[k]=x[i];
			  i +=1;
			  k +=1;
		  }else {
			  r[k]=y[j];
			  j +=1;
			  k +=1;
		  }
	   }
	   while(i<l) {
		   r[k]=x[i];
		   i +=1;
		   k +=1;
	   }
	   while(j < m) {
		   r[k]=y[j];
		   j +=1;
		   k +=1;
	   } 
   }
   public static void main(String args[]) {
		  int x[]= {10, 5, 15};
		  int y[]= {20, 3, 2};
		  int l=x.length;
		  int m=y.length;
		  int r[]=new int[l + m];
		  Merging(x,y,r,l,m);
		  System.out.println("Merge list is:");
		  for (int i = 0; i < l + m; i++)
	            System.out.print(" " + r[i]);
	  }
}
