package problem_statements;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.Scanner;

public class Serlization_7_2 implements java.io.Serializable{
	static int rollNumber;
	static int age;
	static String name;
	static String address;
	
	public Serlization_7_2(int rollNumber, int age, String name, String address) {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		
	
		System.out.println("Enter rollno,age,name and address:");
		Scanner sc=new Scanner(System.in);
		rollNumber=sc.nextInt();
		
		Scanner sc1=new Scanner(System.in);
		age=sc1.nextInt();
		
		Scanner sc2=new Scanner(System.in);
		name=sc1.next();
		
		Scanner sc3=new Scanner(System.in);
		address=sc1.next();
		
		Serlization_7_2 ser=new Serlization_7_2(rollNumber,age,name,address);
		String filename = "file.ser"; 
   
        try
        {    
            //Saving of object in a file 
            FileOutputStream file = new FileOutputStream(filename); 
            ObjectOutputStream out = new ObjectOutputStream(file); 
              
            // Method for serialization of object 
            out.writeObject(ser); 
              
            out.close(); 
            file.close(); 
              
            System.out.println("Object has been serialized");  
        } 
          
        catch(IOException ex) 
        { 
            System.out.println("IOException is caught"); 
        } 
   
	}

}
