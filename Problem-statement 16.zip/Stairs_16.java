package problem_statements;

import java.util.Scanner;

public class Stairs_16 {
    
	public static int stairs(int g) {
		if(g<=1)
			return g;
		return stairs(g-1)+stairs(g-2);
	}
	public static int countStairs(int c) {
		return stairs(c+1);
	}
	
	@SuppressWarnings("resource")
	public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter the no of steps:");
	int c=sc.nextInt();
	System.out.println("Number of Ways to climb:"+countStairs(c));
	}

}
