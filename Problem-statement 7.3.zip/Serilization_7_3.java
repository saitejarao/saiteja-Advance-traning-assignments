package problem_statements;

import java.io.FileInputStream;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Scanner;
public class Serilization_7_3 implements java.io.Serializable {
	static int rollNumber;
	static int age;
	static String name;
	static String address;
	
	public Serilization_7_3(int rollNumber, int age, String name, String address) {
		// TODO Auto-generated constructor stub
	}
	public static void main(String[] args) 
    {
		System.out.println("Enter rollno,age,name and address:");
		Scanner sc=new Scanner(System.in);
		rollNumber=sc.nextInt();
		
		Scanner sc1=new Scanner(System.in);
		age=sc1.nextInt();
		
		Scanner sc2=new Scanner(System.in);
		name=sc1.next();
		
		Scanner sc3=new Scanner(System.in);
		address=sc1.next();
		
		Serilization_7_3 ser=new Serilization_7_3(rollNumber,age,name,address);
		String filename = "file.ser"; 
   
        try
        {    
            //Saving of object in a file 
            FileOutputStream file = new FileOutputStream(filename); 
            ObjectOutputStream out = new ObjectOutputStream(file); 
              
            // Method for serialization of object 
            out.writeObject(ser); 
              
            out.close(); 
            file.close(); 
              
            System.out.println("Object has been serialized");  
        } 
          
        catch(IOException ex) 
        { 
            System.out.println("IOException is caught"); 
        } 
   
		Serilization_7_3 object1 = null;
	try
    {    
        // Reading the object from a file 
        FileInputStream file = new FileInputStream(filename); 
        ObjectInputStream in = new ObjectInputStream(file); 
          
        
        object1 = (Serilization_7_3)in.readObject(); 
          
        in.close(); 
        file.close(); 
          
        System.out.println("Object has been deserialized "); 
        System.out.println("rollNumber = " + object1.rollNumber); 
        System.out.println("age = " + object1.age); 
        System.out.println("name = " + object1.name); 
        System.out.println("address = " + object1.address); 
    } 
      
    catch(IOException ex) 
    { 
        System.out.println("IOException is caught"); 
    } 
      
    catch(ClassNotFoundException ex) 
    { 
        System.out.println("ClassNotFoundException is caught"); 
    } 

} 
}
