package problem_statements;

class fire extends Thread{
	public void run() {
		for(int i=1;i<=10;i++) {
			System.out.println("For fire thread i is"+i);
		}
		System.out.println("Exiting from the thread");
	}
}
class water extends Thread{
	public void run() {
		for(int j=1;j<=10;j++) {
			System.out.println("For water thread i is"+j);
		}
		System.out.println("Exiting from the thread");
	}
}
public class Thread_8_3 {

	public static void main(String[] args) {
		fire f=new fire();
		water w=new water();
		
		f.start();
		w.start();

	}

}
