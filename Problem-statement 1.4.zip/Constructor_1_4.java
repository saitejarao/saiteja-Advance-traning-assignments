package problem_statements;

public class Constructor_1_4 {
public float length,width;
public float getLength() {
	return length;
}
public void setLength(float length) {
	this.length = length;
}
public float getWidth() {
	return width;
}
public void setWidth(float width) {
	this.width = width;
}
public Constructor_1_4(){
	length=1;
	width=1;
}
public void perimeter() {
	System.out.println("Perimeter is:"+(length*width)*2);
}
public void area() {
	System.out.println("Area of Rectangle:"+(length*width));
}
public void setValues() {
	System.out.println("set function");
	if(length>0 && length<20) {
		this.length=length;
		System.out.println("length is above 0 and below 20");
	}
	if(width>0 && width<20) {
		this.width=width;
		System.out.println("width is above 0 and below 20");
	}
}
public static void main(String args[]) {
	Constructor_1_4 o=new Constructor_1_4();
	o.perimeter();
	o.area();
	o.setValues();
}
}
