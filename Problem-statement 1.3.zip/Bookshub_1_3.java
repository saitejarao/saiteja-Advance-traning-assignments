package problem_statements;

import java.util.Scanner;

class Books {
	String Book_title;
	int Book_price;

	public String getBook_title() {
		return Book_title;
	}

	public void setBook_title(String book_title) {
		Book_title = book_title;
	}

	public int getBook_price() {
		return Book_price;
	}

	public void setBook_price(int book_price) {
		Book_price = book_price;
	}
}

public class Bookshub_1_3{
	
	static Books b=new Books();
	
	public static void createBooks(){
		
		while(true) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the book_title and book_price");
		String booktitle=sc.nextLine();
		int bookprice=sc.nextInt();
		b.setBook_title(booktitle);
        b.setBook_price(bookprice);	
        break;
        }	
	}
	
    public static void showBooks(){
    	System.out.println("Book_title     Book_price");
    	System.out.println(b.getBook_title()+"               "+b.getBook_price());
	}
	
	public static void main(String args[]) {	
	createBooks();
	showBooks();
		
	}
	
	
}