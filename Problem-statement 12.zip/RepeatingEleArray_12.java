package problem_statements;

import java.util.HashSet;

public class RepeatingEleArray_12 {
    static void RepeatingElementArray(int arr[]) {
    	int g=-1;
    	HashSet<Integer> set = new HashSet<>();
   	    
        for (int i=arr.length-1; i>=0; i--)
        {
            if (set.contains(arr[i]))
                g = i;
            else   
                set.add(arr[i]);
        }    
        if (g != -1)
          System.out.println("The first repeating element is " + arr[g]);
        else
          System.out.println("There are no repeating elements");
    }
	public static void main(String[] args) {
		int arr[] = {3,7,8,2,4,5,2,8,6};
		RepeatingElementArray(arr);
        
        int arr1[] = {5,6,9,3,4,3,1,9,5};
        RepeatingElementArray(arr1);
        
        int arr2[] = {4,2,1,3,4,4,3,2,5};
        RepeatingElementArray(arr2);
	}
}