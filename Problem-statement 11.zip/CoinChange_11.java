package problem_statements;

import java.util.Scanner;
import java.util.Vector;

public class CoinChange_11 {
	 static int denomination[] = {1, 2, 5, 10, 20, 50, 100, 500, 1000};
			    static int g = denomination.length;
			  
			    static void findMin(int V)
			    {
			   	    Vector<Integer> b = new Vector<>();
			       	for (int i=g-1;i>=0;i--)
			        { 
			            while (V >= denomination[i]) 
			            {
			                V -= denomination[i];
			                b.add(denomination[i]);
			            }
			        }
			  
			        
			        for (int i = 0; i < b.size(); i++)
			        {
			            System.out.print(" " + b.elementAt(i));
			        }
			        System.out.println("\nThe minimum number of coins is "+b.size());
			    }
			  
			   
			    public static void main(String[] args) 
			    {
			    	Scanner scanner=new Scanner(System.in);
			    	System.out.println("Enter the number");
			    	int a=scanner.nextInt();
			        System.out.print("The minimum number of change or notes needed for " + a + ": ");
			        findMin(a);
			    }
}
