package constructor;

class User{
	
	public void Laptop(int l, int w)
	{
		System.out.println("Area of Laptop: "+(l*w));
	}
	public void Book(int f, int d)
	{
		System.out.println("Area of Book: "+(f*d));
	}
	public void Phone(int a, int b)
	{
		System.out.println("Area of Phone: "+(a*b));
	}
	public void Door(int p,int q)
	{
		System.out.println("Area of rhombus: "+(p*q));
	}
	public void Table(int c,int b)
	{
		System.out.println("Area of Table: "+(c*b));
	}	
}
public class TestRectangle_1_2_d {

	public static void main(String[] args) {
		System.out.println("Area's of Rectangle objects:");
		User u=new User();
		u.Laptop(2,3);
		u.Book(4,5);
		u.Phone(2,8);
		u.Door(3,6);
		u.Table(2,6);

	}

}
