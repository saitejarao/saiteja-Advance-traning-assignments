package constructor;
class Rectangle{
int length;
int breadth;
public int getLength() {
	return length;
}
public void setLength(int length) {
	this.length = length;
}
public int getBreadth() {
	return breadth;
}
public void setBreadth(int breadth) {
	this.breadth = breadth;
}
    Rectangle(){
	length=10;
	breadth=20;
	}
    public void area(){
    	System.out.println("Area:"+(length*breadth));
    }
    public void Information() {
    	System.out.println("Rectangle has four sides");
    	System.out.println("In rectangle two sides are equal");
    	System.out.println("Rectangle has length and breadth");
    }
}
public class Constructor_1_2_1 {

	public static void main(String[] args) {
	Rectangle r=new Rectangle();
	r.area();
	r.Information();
	}
}
