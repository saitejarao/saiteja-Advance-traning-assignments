package problem_statements;

import java.util.ArrayDeque;
import java.util.Deque;

public class CheckingBalancedBrackets_17 {
    static boolean CheckingBalancedBrackets(String str)
    {
    	Deque<Character> ch=new ArrayDeque<Character>();
    	
    	for(int i=0;i<str.length();i++) {
    		char x=str.charAt(i);
    		if(x=='(' || x=='[' || x=='{')
    		{
    			ch.push(x);
    			continue;
    		}
    		if(ch.isEmpty())
    			return false;
    		char verify;
    		switch(x) {
    		case ')':
    			verify=ch.pop();
    			if(verify=='{' || verify=='[')
    				return false;
    			break;
    			
    		case '}':
    			verify=ch.pop();
    			if(verify=='(' || verify=='[')
    				return false;
    			break;
    			
    		case ']':
    			verify=ch.pop();
    			if(verify=='(' || verify=='{')
    				return false;
    			break;	
    		}
    	}
		return (ch.isEmpty());
    }
	public static void main(String[] args) {
		 String str="][";
		 if(CheckingBalancedBrackets(str))
			 System.out.println("Balanced");
		 else
			 System.out.println("Not Balanced");
	}
}