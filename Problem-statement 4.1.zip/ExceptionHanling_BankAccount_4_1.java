package problem_statements;

public class ExceptionHanling_BankAccount_4_1 {
int accNo;
String custName;
String accType;
double balance;

public int getAccNo() {
	return accNo;
}

public void setAccNo(int accNo) {
	this.accNo = accNo;
}

public String getCustName() {
	return custName;
}

public void setCustName(String custName) {
	this.custName = custName;
}

public String getAccType() {
	return accType;
}

public void setAccType(String accType) {
	this.accType = accType;
}

public double getBalance() {
	if(balance<1000) {
		try {
			throw new NumberFormatException();
		}
		catch(NumberFormatException nw) {
			System.out.println("Balance is low ="+balance);
		}
	}
	return balance;
}

public void setBalance(float balance) {
	this.balance = balance;
}


public ExceptionHanling_BankAccount_4_1(int accNo, String custName, String accType, float balance) {
	this.accNo = accNo;
	this.custName = custName;
	this.accType = accType;
	this.balance = balance;
}
public ExceptionHanling_BankAccount_4_1() {
	this.accNo = 65842082;
	this.custName = "Jai";
	this.accType = "Savings";
	this.balance = 500;
}
void deposit(double amt)
{
    if(amt<0)
    {
        try
        {
            throw new NumberFormatException();
        }
        catch(NumberFormatException nf)
        {
            System.out.println(" Amount can't be negative");
        }
    }
    else
    {
        balance=getBalance()+amt;
        System.out.println("Current balance is ="+balance);
       
    }
}
 public void withdraw(double amt){
     if(amt>1000)
        {
            try
            {
                throw new NumberFormatException();
            }
            catch(NumberFormatException nf)
            {
                System.out.println("Less Balance ");
            }
        }
        else
        {
            balance=getBalance()-amt;
            System.out.println("Current balance is ="+balance);  
        }  
}
 void display()
 {
System.out.println("Balance is ="+getBalance());   
 }
public static void main(String[] args) {
	
	ExceptionHanling_BankAccount_4_1 b=new ExceptionHanling_BankAccount_4_1();
	b.deposit(3500);
	b.display();
	b.withdraw(1000);
	b.display();
    b.withdraw(1250);
    b.getBalance();
    b.display();
	}

}
