package problem_statements;

public class split_5_2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       String g="23 + 45 - ( 343 / 12 )";
       String[] res=g.split("\\s");
       
       for(String r:res){  
   		System.out.println(r); 
   		//System.out.println(" ");
   	}
	}

}
