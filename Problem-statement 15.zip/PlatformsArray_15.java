package problem_statements;

public class PlatformsArray_15 {
    public static int platformsRequired(int arr[],int dep[],int g) {
    	int platforms=1,result=1;
    	int a=1,b=0;
    	
    	for(a=0;a<g;a++) {
    		platforms=1;
    		for(b=a+1;b<g;b++) {
    			if ((arr[a] >= arr[b] && arr[a] <= dep[b])||
    					(arr[b] >= arr[a] && arr[b] <= dep[a]))
    				platforms++;
    		}
    		result=Math.max(result, platforms);
    	}
    	return result;
    }
	public static void main(String[] args) {
	    int	arr[] = { 900, 940, 950, 1100, 1500, 1800 };
		int dep[] = { 910, 1200, 1120, 1130, 1900, 2000 };
        int g=6;
	    System.out.println("Minimum number of platforms needed:"+platformsRequired(arr,dep,g));
	}

}
