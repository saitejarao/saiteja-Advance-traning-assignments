package com.mycompany.app;

import java.io.BufferedReader;

import java.io.InputStreamReader;
import java.util.List;

import com.mycompany.dao.ProductManagementDAO;
import com.mycompany.domain.Product;

public class ProductManagementApp {
	static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
    static ProductManagementDAO dao = new ProductManagementDAO();
    public static void main(String[] args) throws Exception
    {
    	String option="";
    	
    	do
    	{
    		System.out.println("A. View Products");
    		System.out.println("B. Add Products");
    		System.out.println("C. Update Products");
    		System.out.println("D. Delete Products");
    		System.out.println("E. Search Products");
    		System.out.println("F. Exit");
    		System.out.println("=====================================");
    		System.out.println("Enter an option");
    		System.out.println("=====================================");
    		option=br.readLine();
    		System.out.println("\n");
    		
    		switch(option.toUpperCase())
    		{
            case "A":
                viewProducts();
                break;

            case "B":
                addProduct();
                break;

            case "C":
                updateProduct();
                break;

            case "D":
                deleteProduct();
                break;

            case "E":
                searchProduct();
                break;

            case "F":
                System.out.println("******************************THANK YOU********************");
                System.exit(0);
                break;

            default:
                System.out.println("Invalid Option! Please enter again");
                break;
            }
    	}while(!option.equals("F"));
    }
    public static void viewProducts()
    {
    	System.out.println("-------------------------------------------");
    	List<Product> productList=dao.getAllProducts();
    	for(Product product:productList)
    	{
    		displayProduct(product);
    	}
    	System.out.println("-------------------------------------------");
    	System.out.println("\n");
    }
    
    public static void addProduct() throws Exception
    {
    	System.out.println("-------------------------------------------");
    	System.out.println("Enter the Product Id:");
    	System.out.println("-------------------------------------------");
    	int PId=Integer.parseInt(br.readLine());
    	System.out.println("-------------------------------------------");
    	System.out.println("Enter the Product Name:");
    	System.out.println("-------------------------------------------");
    	String PName=br.readLine();
    	System.out.println("-------------------------------------------");
    	System.out.println("Enter the Product Price:");
    	System.out.println("-------------------------------------------");
    	int PPrice = Integer.parseInt(br.readLine());
    	Product product = new Product(PId,PName,PPrice);
        int status = dao.addProduct(product);
        if(status ==1 )
        {
            System.out.println("Product added successfully");
        }
        else
        {
            System.out.println("ERROR while adding product");
        }
        System.out.println("\n");
    }
    public static void updateProduct() throws Exception
    {
        System.out.println("------------------------------------------------");
        System.out.println("Enter the Product ID:");
        System.out.println("------------------------------------------------");
        int PId = Integer.parseInt(br.readLine());
        System.out.println("------------------------------------------------");
        System.out.println("Enter New Product Name:");
        System.out.println("------------------------------------------------");
        String PName = br.readLine();
        System.out.println("------------------------------------------------");
        System.out.println("Enter New Product Price:");
        System.out.println("------------------------------------------------");
        int PPrice = Integer.parseInt(br.readLine());
        Product product = new Product(PId, PName,PPrice);
        int status = dao.updateProduct(product);
        if(status ==1 )
        {
            System.out.println("Product updated successfully");
        }
        else
        {
            System.out.println("ERROR while updating product");
        }
        System.out.println("\n");

    }

    public static void deleteProduct() throws Exception
    {
        System.out.println("------------------------------------------------");
        System.out.println("Enter Product ID:");
        System.out.println("------------------------------------------------");
        int PId = Integer.parseInt(br.readLine());
        int status = dao.deleteProduct(PId);
        if(status == 1 )
        {
            System.out.println("Product deleted successfully");
        }
        else
        {
            System.out.println("ERROR while deleting product");
        }
        System.out.println("\n");

    }

    //ask user for productId and use dao method to display product
    public static void searchProduct() throws Exception
    {
        System.out.println("------------------------------------------------");
        System.out.println("Enter Product ID:");
        System.out.println("------------------------------------------------");
        String PId = br.readLine();
        Product product = dao.getProductById(PId);
        displayProduct(product);
        System.out.println("\n");
    }

    public static void displayProduct(Product product)
    {
        System.out.println("Product ID: "+product.getPId());
        System.out.println("Product Name: "+product.getPName());
        System.out.println("Product Price: "+product.getPPrice());
        System.out.println("\n");
    }
}
