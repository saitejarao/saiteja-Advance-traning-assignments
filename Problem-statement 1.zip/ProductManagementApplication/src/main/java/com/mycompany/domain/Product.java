package com.mycompany.domain;

public class Product {

	int PId;
	String PName;
	int PPrice;
	
	public Product(int pId, String pName, int pPrice) {
		super();
		PId = pId;
		PName = pName;
		PPrice = pPrice;
	}
	
	public Product() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getPId() {
		return PId;
	}
	public void setPId(int pId) {
		PId = pId;
	}
	public String getPName() {
		return PName;
	}
	public void setPName(String pName) {
		PName = pName;
	}
	public int getPPrice() {
		return PPrice;
	}
	public void setPPrice(int pPrice) {
		PPrice = pPrice;
	}
	@Override
	public String toString() {
		return "Product [PId=" + PId + ", PName=" + PName + ", PPrice=" + PPrice + "]";
	}
	
}
