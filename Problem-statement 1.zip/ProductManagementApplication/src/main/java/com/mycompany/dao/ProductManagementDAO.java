package com.mycompany.dao;

import java.sql.*;

import java.util.ArrayList;
import java.util.List;

import com.mycompany.dbutil.DBUtil;
import com.mycompany.domain.Product;

public class ProductManagementDAO {
  
	public List<Product> getAllProducts()
	{
		List<Product> productList=new ArrayList<Product>();
		try{
			Connection conn=DBUtil.getConnection();
			Statement st=conn.createStatement();
			ResultSet rs=st.executeQuery("Select * from product");
			while(rs.next())
			{
				Product product=new Product(rs.getInt("PId"), rs.getString("PName"), rs.getInt("PPrice"));
				productList.add(product);
			}
			DBUtil.closeConnection(conn);
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return productList;
	}
	
	public Product getProductById(String productId)
	{
		Product product=null;
		try{
			Connection conn=DBUtil.getConnection();
			PreparedStatement ps=conn.prepareStatement("select * from product where PId=?");
			ps.setString(1, productId);
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				product=new Product(rs.getInt("PId"), rs.getString("PName"), rs.getInt("PPrice"));
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return product;
	}
	
	public int addProduct(Product product)
	{
		int status=0;
		try{
			Connection conn=DBUtil.getConnection();
			PreparedStatement ps=conn.prepareStatement("Insert into product values(?,?,?)");
			ps.setInt(1, product.getPId());
			ps.setString(2, product.getPName());
			ps.setInt(3, product.getPPrice());
			status=ps.executeUpdate();
	
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return status;
	}
	
	public int updateProduct(Product product)
	{
		int status=0;
		try{
			Connection conn=DBUtil.getConnection();
			PreparedStatement ps=conn.prepareStatement("Update product set PName=?,PId=?,PPrice=? where PId=?");
			ps.setString(1, product.getPName());
			ps.setInt(2, product.getPId());
			ps.setInt(3, product.getPPrice());
			status=ps.executeUpdate();
	
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return status;
	}
	
	public int deleteProduct(int PId)
	{
		int status=0;
		try{
			Connection conn=DBUtil.getConnection();
			PreparedStatement ps=conn.prepareStatement("delete from product where PId=?");
			
			ps.setInt(1,PId);
			status=ps.executeUpdate();
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return status;
	}
	
}
